package com.example.todoapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.example.todoapp.Models.Note;
import com.example.todoapp.databinding.MainsimpleBinding;

 public class RvAdapter extends ListAdapter<Note, RvAdapter.ViewHolder> {



    public RvAdapter(){
        super(CALLBACK);
    }
   private static final DiffUtil.ItemCallback<Note> CALLBACK =new DiffUtil.ItemCallback<Note>() {
            @Override
            public boolean areItemsTheSame(@NonNull Note oldItem, @NonNull Note newItem) {
                return oldItem.getId()== newItem.getId();
            }

            @Override
            public boolean areContentsTheSame(@NonNull Note oldItem, @NonNull Note newItem) {
                return oldItem.getTitle().equals(newItem.getTitle()) && oldItem.getDisp().equals(newItem.getDisp());
            }
        } ;


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.mainsimple,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
      Note note=getItem(position);
      holder.binding.titleRv.setText(note.getTitle());
      holder.binding.dispRv.setText(note.getDisp());
    }
 public Note getNote(int position){
       return getItem(position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        MainsimpleBinding binding;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            binding=MainsimpleBinding.bind(itemView);
        }
    }
}

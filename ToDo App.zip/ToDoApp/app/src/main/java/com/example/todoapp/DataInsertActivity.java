package com.example.todoapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.todoapp.databinding.ActivityDataInsertBinding;

import java.util.Objects;

public class DataInsertActivity extends AppCompatActivity {
    ActivityDataInsertBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDataInsertBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        String type = getIntent().getStringExtra("type");
        if (type.equals("Update")) {
            setTitle("Update");
            binding.titleTv.setText(getIntent().getStringExtra("title"));
            binding.dispTv.setText(getIntent().getStringExtra("disp"));
            int id=getIntent().getIntExtra("id",0);
            binding.insertData.setText("Update Now");
            binding.insertData.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                        Intent intent = new Intent();
                        intent.putExtra("title", binding.titleTv.getText().toString());
                        intent.putExtra("disp", binding.dispTv.getText().toString());
                        intent.putExtra("id", id);
                        setResult(RESULT_OK, intent);
                        finish();
                }
            });
        } else {
            setTitle("Add Mode");
            binding.insertData.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String type = binding.titleTv.getText().toString();
                    String disp = binding.dispTv.getText().toString();
                    if (type.equals("")) {
                        binding.titleTv.setError("please fill this");
                    } else
                        if (disp.equals("")) {
                            binding.dispTv.setError("please fill this");
                        }
                    else {  if (!type.equals("") && !disp.equals("")){
                        Intent intent = new Intent();
                        intent.putExtra("title", binding.titleTv.getText().toString());
                        intent.putExtra("disp", binding.dispTv.getText().toString());
                        setResult(RESULT_OK, intent);
                        finish();
                    }}}
            });


        }
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
   }
}